// var shuffleSequence = seq("welcome", "item");
// var shuffleSequence = seq("item");
var shuffleSequence = seq("welcome", "item", rshuffle(startsWith("critical")));

var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: true,
        instructions: "Is this a real word?",
        as: ["F: No", "J: Yes"]
    }
];

var items = [

    ["setcounter", "__SetCounter__", {}],

    // Simple message
    // ["welcome", "Message", {
    //     html: "Welcome to our experiment!"
    // }],

    // // Acceptability judgment
    // ["item", "AcceptabilityJudgment", {
    //     s: { html: 'cat' },
    //     q: "Is this a real word?",
    //     as: ["F: No", "J: Yes"]
    // }],

    // // Presenting the options as a scale (two button press)
    // ["item", "AcceptabilityJudgment", {
    //     s: { html: 'cat' },
    //     q: "Is this a real word?",
    //     as: ["F: No", "J: Yes"],
    //     presentAsScale: true
    // }],

    // // If we want to keep the same options,
    // // we can set the default in the beginning of this document (see var defaults)
    // // (e.g., the same question, presentAsScale: true, as: ["F: No","J: Yes"]),
    // ["item", "AcceptabilityJudgment", {
    //     s: { html: 'cat' }
    // }],

    // // Combining different controllers in a single item
    // ["item", "Message", { html: 'dog' }, 
    //          "AcceptabilityJudgment", { s: { html: 'cat' } 
    // }],
    
    // // Let's move the first word to the center of the screen
    // ["item", "Message", { html:'<center> dog </center>' }, 
    //          "AcceptabilityJudgment", { s: { html:'cat' } 
    // }],
    
    // // Let's make the transition from the first message to the second happen by keypress.
    // ["item", "Message", { html:'<center> dog </center>', transfer: 'keypress'}, 
    //          "AcceptabilityJudgment", { s: { html:'cat' } 
    // }],
    
    // // We should let people know that a key needs to be pressed.
    // ["item", "Message", { html:'<center> dog <p> press any key </p> </center>', 
    //                       transfer: 'keypress'}, 
    //          "AcceptabilityJudgment", { s: { html:'cat' } 
    // }],

    // An example of a lexical decision task:
    ["item", "Message", { html: '<center> + <p> Look at the + and press any key to proceed. </p> </center>',
                          transfer: "keypress" 
                        },
             "Message", { html: '<center> whale </center>', 
                          transfer: 100 
                        }, 
             "Message", { html: ' ', 
                           transfer: 200
                        }, 
             "AcceptabilityJudgment", { 
                    s: { html: 'shark' } 
                }],
    
    ["item", "Message", { html: '<center> + <p> Look at the + and press any key to proceed. </p> </center>',
                          transfer: "keypress" 
                        },
             "Message", { html: '<center> sharp </center>', 
                          transfer: 100 
                        }, 
             "Message", { html: ' ', 
                           transfer: 200
                        }, 
             "AcceptabilityJudgment", { 
                    s: { html: 'shark' } 
                }],
                
    // (you can also change the font size)
    ["item", "Message", { html: '<center> + <p> Look at the + and press any key to proceed. </p> </center>',
                          transfer: "keypress" 
                        },
             "Message", { html: '<center> <font size="12"> butter </font> </center>', 
                          transfer: 100 
                        }, 
             "Message", { html: ' ', 
                           transfer: 200
                        }, 
             "AcceptabilityJudgment", { 
                    s: { html: '<font size="12"> shark </font>' } 
                }],
    
    // Making participants see only one condition for each item
    [["critical_sem",1], 
             "Message", { html: '<center> + <p> Look at the + and press any key to proceed. </p> </center>',
                          transfer: "keypress" 
                        },
             "Message", { html: '<center> whale </center>', 
                          transfer: 100 
                        }, 
             "Message", { html: ' ', 
                           transfer: 200
                        }, 
             "AcceptabilityJudgment", { 
                    s: { html: 'shark' } 
                }],
                
    [["critical_phn",1], 
             "Message", { html: '<center> + <p> Look at the + and press any key to proceed. </p> </center>',
                          transfer: "keypress" 
                        },
             "Message", { html: '<center> sharp </center>', 
                          transfer: 100 
                        }, 
             "Message", { html: ' ', 
                           transfer: 200
                        }, 
             "AcceptabilityJudgment", { 
                    s: { html: 'shark' } 
                }],
                
    [["critical_unr",1], 
             "Message", { html: '<center> + <p> Look at the + and press any key to proceed. </p> </center>',
                          transfer: "keypress" 
                        },
             "Message", { html: '<center> butter </center>', 
                          transfer: 100 
                        }, 
             "Message", { html: ' ', 
                           transfer: 200
                        }, 
             "AcceptabilityJudgment", { 
                    s: { html: 'shark' } 
                }]
];
