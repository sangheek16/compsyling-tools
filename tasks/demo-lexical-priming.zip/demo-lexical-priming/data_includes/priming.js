var shuffleSequence = seq("demog","quest","instr",rshuffle(startsWith("item")));

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: true,
        instructions: "",
        randomOrder: false,
        hasCorrect: false,
        hideProgressBar: true
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

/*
AcceptabilityJudgment flashes a sentence "s"
	"s" can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/

var items = [

["setcounter", "__SetCounter__", { }],


["demog", "Form", {consentRequired: true, html: {include: "demog.html" }} ],
["quest", "Form", {consentRequired: true, html: {include: "quest.html" }} ],
["instr", "Form", {consentRequired: true, html: {include: "instr.html" }} ],

[["item1phn", 1], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> SHARP </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SHARK </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item1sem", 1], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> WHALE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200}, 
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SHARK </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item1unr", 1], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> BUTTER </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SHARK </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],  

[["item2phn", 2], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> MIRE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> MILE </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item2sem", 2], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> INCH </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> MILE </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item2unr", 2], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> FORK </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> MILE </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item3phn", 3], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> GREAT </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> GRAPE </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item3sem", 3], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> CHERRY </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> GRAPE </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item3unr", 3], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> HOUSE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> GRAPE </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item4phn", 4], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> BEAT </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> BEAN </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item4sem", 4], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> LENTIL </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> BEAN </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item4unr", 4], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> HAND </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> BEAN </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item5phn", 5], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> RIVET </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> RIVER </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item5sem", 5], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> STREAM </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> RIVER </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item5unr", 5], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> BRICK </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> RIVER </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item6phn", 6], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> SPOOF </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SPOON </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item6sem", 6], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> KNIFE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SPOON </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item6unr", 6], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> TREE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SPOON </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item7phn", 7], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> SHEET </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SHEEP </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item7sem", 7], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> COW </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SHEEP </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item7unr", 7], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> PIN </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SHEEP </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item8phn", 8], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> DIVE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> DIME </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item8sem", 8], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> DOLLAR </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> DIME </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item8unr", 8], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> CLASP </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> DIME </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item9phn", 9], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> HARD </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> HARP </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item9sem", 9], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> VIOLIN </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> HARP </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item9unr", 9], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> CAP </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> HARP </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item10phn", 10], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> SILT </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SILK </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item10sem", 10], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> COTTON </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SILK </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item10unr", 10], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> TILE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SILK </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item11phn", 11], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> SHIRK </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SHIRT </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item11sem", 11], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> COAT </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SHIRT </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item11unr", 11], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> FOX </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SHIRT </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item12phn", 12], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> STEEP </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> STEEL </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item12sem", 12], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> COPPER </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> STEEL </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item12unr", 12], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> RACE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> STEEL </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item13phn", 13], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> TRADE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> TRAIN </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item13sem", 13], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> CAR </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> TRAIN </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item13unr", 13], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> CLIP </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> TRAIN </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item14phn", 14], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> SPIKE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SPICE </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item14sem", 14], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> SALT </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SPICE </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item14unr", 14], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> COVER </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SPICE </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item15phn", 15], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> SPEAK </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SPEAR </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}], 

[["item15sem", 15], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> SWORD </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SPEAR </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["item15unr", 15], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> RAIL </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SPEAR </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 1}],

[["itemF1", 16], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> CAT </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> THAFE </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],  

[["itemF2", 17], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> HORN </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SPLOONS </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],     

[["itemF3", 18], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> PASS </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> WEFF </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],    

[["itemF4", 19], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> TYPE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> ZERM </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],    

[["itemF5", 20], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> HOT </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> STROUT </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],    

[["itemF6", 21], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> LADDER </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> PLECK </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],    

[["itemF7", 22], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> PEEL </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> FLELM </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],  

[["itemF8", 23], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> FILM </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> VAUM </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],  

[["itemF9", 24], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> WINDOW </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> KLOAB </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],  

[["itemF10", 25], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> BOTTLE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> DROLM </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],  

[["itemF11", 26], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> CYCLE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> THEAN </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],    

[["itemF12", 27], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> STAIRS </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> SKRAIN </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],    

[["itemF13", 28], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> HANDLE </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> VEV </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],    

[["itemF14", 29], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> LEFT </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> WOGGED </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}],  

[["itemF15", 30], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> REACH </center></font>', transfer: 50}, "Message", {html:' ', transfer: 200},
"AcceptabilityJudgment", {s: {html:'<font size="6"><center> YARKS </center></font>'}, q: "", as: ["F: non","J: word"], hasCorrect: 0}] 

/*comma*/

];