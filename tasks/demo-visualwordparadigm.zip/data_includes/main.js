// Experiment code manipulated from Slim & Hartsuiker's Experiment 2
// This script uses PennController Version 2.0
// Make sure to use the correct syntax for using plugins
// if you are using a different version

PennController.ResetPrefix(null) // Shorten command names (keep this)
// PennController.DebugOff() // Don't show the debug window

// Host for loading resources (use a .zip file for faster loading)
PreloadZip("https://mondo1.dreamhosters.com/sk-cb-their-large-2b.zip");

// PHP script that receives, stores (and will also output) the eye-tracking data 
// EyeTrackerURL("YOUR HOST URL")
EyeTrackerURL("https://mondo1.dreamhosters.com/script.php?experiment=")

// Change ProgressBar status
var showProgressBar = true;

// Sequence of the elements in the experiment
Sequence("Preload", "Loading", "Consent", "Prolific", "Welcome", "WebcamCheck", "ChromeCheck", "L1Check", "WebcamSetUp", "FailedCalibrationLink", "AudioSetUp", "Instructions", "PracticeSession", "EndOfPractice", "Counter", rshuffle("Block1_target", "Block1_filler"), "BlinkBreak", "AudioSetUp2", rshuffle("Block2_target", "Block2_filler"), "LanguageQuestionnairePage", "Send", "Payment", "FinalPage")
// Sequence("Preload", "Loading", "Prolific", "WebcamCheck", "ChromeCheck", "L1Check", "Welcome", "Consent", "WebcamSetUp", "FailedCalibrationLink", "AudioSetUp", "Instructions", "PracticeSession", "EndOfPractice", "Counter", rshuffle("Block1_target", "Block1_filler"), "BlinkBreak", "AudioSetUp2", rshuffle("Block2_target", "Block2_filler"), "LanguageQuestionnairePage", "Send", "Payment", "WebcamQuestionnairePage", "FinalPage")

// -- NOTE on Calibration process
// We give 3 chances to participants to recalibrate
// The initial calibration process should meet the threshold above 60 // <- changed to 40 for demo
// Those who didn't pass the initial calibration cannot participate (no payment)
// No calibration process is required during the practice trials
// Between trials we check the calibration score on the centered dot
// If the calibration score is below 30, then we can participants to
// go over the calibration process (score 30) again
// If they fail to pass the 3 chances of recalibration process
// They are given the completion code and will be exited from the experiment

// -- Visual World Paradigm setup
// 500 ms of '+' fixation time
// Fixation cross disappears and then 2200 ms of preview time of four images
// 500 ms overspill after audio finished playing
// 200 ms overspill time before the question appears
// Mouse cursor is activated right after the question appears
// No time constraint on picture selection

// Check preload of required files:
CheckPreloaded("Preload")

// Below is a fake loading page.
newTrial("Loading",
    newText("Loading", "Loading...")
        .css("font-family", "Arial, sans-serif")
        .center()
        .print()
    ,
    // After a 1000 ms, a continue button is printed.
    newTimer(1000)
        .start()
        .wait()
    ,
    getText("Loading")
        .remove()
    ,
    newText("Click on the button below to start the experiment!")
        .css("font-family", "Arial, sans-serif")
        .center()
        .print()
    ,
    newButton("Continue to the experiment")
        .css("font-family", "Arial, sans-serif")
        .center()
        .print()
        .wait()
)

// Prolific number
newTrial("Prolific",
    newHtml("prolific_id", "Prolific.html")
        .center()
        .cssContainer({"width":"720px"})
        .checkboxWarning("You must enter your ID before continuing.")
        .print()
        .log()
    ,
    newButton("continue", "Click to continue")
        .center()
        .print()
        .wait(getHtml("prolific_id").test.complete()
                  .failure(getHtml("prolific_id").warn())
        )
)

// Payment
newTrial("Payment",
    newHtml("payment_code", "PayCode.html")
        .center()
        .cssContainer({"width":"720px"})
        .print()
        .log()
    ,
    newButton("continue", "Click to continue")
        .center()
        .print()
        .wait(getHtml("payment_code").test.complete()
                  .failure(getHtml("payment_code").warn())
        )
)

// Get consent for webcam access
newTrial("WebcamCheck",
    newText("PermissionWebcam", 
            `<p>Three brief questions before we begin:</p>
            <p>We need to use your webcam to record where you are 
            looking at on the screen.<br>
            We will <b>not</b> record any video or collect any other 
            type of data that may reveal your identity. <br><br>
            Do you give us permission to use your webcam?</p>`)
        .css("font-family", "Arial, sans-serif")
    ,
    // They indicate their response with a keyboard press
    newText("NoPermission", "No, I do not give my permission<br>Press the 'J' key")
        .css("font-family", "Arial, sans-serif")
    ,
    newText("YesPermission", "Yes, I give my permission,<br>Press the 'F' key")
        .css("font-family", "Arial, sans-serif")
    ,
    newCanvas("ChecksCanvas", "60vw" , "20vh")
        .add("center at 50%", "top at 10%", getText("PermissionWebcam"))
        .css("font-family", "Arial, sans-serif")
        .add("center at 20%", "top at 140%", getText("YesPermission"))
        .css("font-family", "Arial, sans-serif")
        .add("center at 80%", "top at 140%", getText("NoPermission"))
        .css("font-family", "Arial, sans-serif")
        .print("center at 50%", "top at 25%") 
    ,
    // Implement the keyboard response keys
    newKey("yesno", "FJ")
        .wait()
    ,
    // And check which key was pressed
    getKey("yesno")
        // If they select yes 'F', the experiment continues. 
        // If they select no 'J', they are send to a page that says that they cannot participate in the experiment.
        .test.pressed("F")
        .failure(
            getCanvas("ChecksCanvas")
                .remove()
            ,
            newCanvas("NoPermision", "60vw" , "20vh")
                .add("center at 50%", "top at 10%", 
                    newText(`<p>Unfortunately, this experiments requires 
                    your permission to use your webcam. <br> 
                    We kindly suggest you to participate in a different 
                    experiment. Please close the experiment by closing 
                    the browser. <br> 
                    Thank you!</p>`))
                .css("font-family", "Arial, sans-serif")
                .print("center at 50%", "top at 25%") 
            ,
            newButton("waitforever") // The button is never printed, so they're stuck on this page.
                .wait()
        )
)

// The following section works the same as the 'WebcamCheck' section
newTrial("ChromeCheck",
    newText("ChromeCheckText", 
            `<p>Three brief questions before we begin:</p>
            <p>This study only works well if you are using the 
            Google Chrome browser on a laptop or desktop computer 
            (so not on a mobile phone or tablet).
            Are you currently using <b>Google Chrome Desktop</b>?</p>`)
        .css("font-family", "Arial, sans-serif")
    ,
    newText("NoChrome", "No, I am using another browser/device<br>Press the 'J' key")
        .css("font-family", "Arial, sans-serif")
    ,
    newText("YesChrome", "Yes, I am currently using Chrome Desktop<br>Press the 'F' key")
        .css("font-family", "Arial, sans-serif")
    ,
    newCanvas("ChecksCanvas", "60vw" , "20vh")
        .add("center at 50%", "top at 10%", getText("ChromeCheckText"))
        .css("font-family", "Arial, sans-serif")
        .add("center at 20%", "top at 140%", getText("YesChrome"))
        .css("font-family", "Arial, sans-serif")
        .add("center at 80%", "top at 140%", getText("NoChrome"))
        .css("font-family", "Arial, sans-serif")
        .print("center at 50%", "top at 25%") 
    ,
    newKey("yesno", "FJ")
        .wait()
    ,
    getKey("yesno")
        .test.pressed("F")
            .failure(
            getCanvas("ChecksCanvas")
                .remove()
            ,
            newCanvas("NoChrome", "60vw" , "20vh")
                .add("center at 50%", "top at 10%", 
                    newText(`<p>Unfortunately, this experiment only works
                            on Google Chrome (which can be downloaded for 
                            free). <br> Please close the experiment by 
                            closing the browser, and come back on Chrome.
                            </p>`))
                .css("font-family", "Arial, sans-serif")
                .print("center at 50%", "top at 25%") 
            ,
            newButton("waitforever")
                .wait()
        )
)

// L1 background check
newTrial("L1Check",
    newText("L1CheckText", 
            `<p>Three brief questions before we begin:</p>
            <p>To participate in this study, it is required that you are
            a <b>native speaker of English</b>. Are you a native speaker 
            of English?</p>`)
        .css("font-family", "Arial, sans-serif")
    ,
    newText("NoL1", "No, I am not a native speaker of English<br>Press the 'J' key")
        .css("font-family", "Arial, sans-serif")
    ,
    newText("YesL1", "Yes, English is my first language<br>Press the 'F' key")
        .css("font-family", "Arial, sans-serif")
    ,
    newCanvas("ChecksCanvas", "60vw" , "20vh")
        .add("center at 50%", "top at 10%", getText("L1CheckText"))
        .css("font-family", "Arial, sans-serif")
        .add("center at 20%", "top at 140%", getText("YesL1"))
        .css("font-family", "Arial, sans-serif")
        .add("center at 80%", "top at 140%", getText("NoL1"))
        .css("font-family", "Arial, sans-serif")
        .print("center at 50%", "top at 25%") 
    ,
    newKey("yesno", "FJ")
        .wait()
    ,
    getKey("yesno")
        .test.pressed("F")
            .failure(
            getCanvas("ChecksCanvas")
                .remove()
            ,
            newCanvas("NoL1", "60vw" , "20vh")
                .add("center at 50%", "top at 10%", 
                    newText(`<p>Unfortunately, you are not eligible to 
                            participate in this study. <br> Please close
                            the experiment by closing the browser -- we 
                            kindly suggest you to participate in a 
                            different experiment. <br> Thank you!</p>`))
                .css("font-family", "Arial, sans-serif")
                .print("center at 50%", "top at 25%") 
            ,
            newButton("waitforever")
                .wait()
        )
)

// Here, a welcome screen is presented to the participant.
newTrial("Welcome",
    // This is a brief download speed test (written in HTML). This test is repeated throughout the experiment. 
    newHtml("downloadspeed", "speedtest.html") 
        .css("font-family", "Arial, sans-serif")
        .log()
    ,
    newVar("Subject", randomnumber = Math.floor(Math.random()*1000000))
        .global()
        .log()
    ,
    newText("WelcomeText", 
            `<p>Welcome and thank you for participating in this 
            experiment.</p>
            <p>In this experiment, you will be listening to short 
            sentences while presented with four images on the screen.<br> 
            Your task is to select one of the four images given the 
            instruction. <br><br> We will be recording your eye movements 
            by using your web camera. We will <b>not</b> collect any 
            video data or any other type of data that may reveal your 
            identity. <br><br> It is important that you are in a 
            well-lit and quiet environment, otherwise the webcam may 
            not be able to pick up your eye movements. Please 
            turn off any devices or applications that may distract you 
            during this task, and please close other websites that you 
            may have open. <br><br> We will test in a moment whether 
            your web camera is compatible with the current experimental 
            setup. In case it doesn’t, we kindly ask you to participate 
            in a different experiment. </p> 
            <p>Press <b>SPACE</b> to continue. <br><br>The next pages 
            will appear in fullscreen. <b>Please do not close the 
            fullscreen for the remainder of this experiment. </b></p>`)
        .css("font-family", "Arial, sans-serif")
    ,
    newCanvas("InstructionsCanvas", "60vw" , "20vh")
        .add(0,0, getText("WelcomeText"))
        .print("center at 50%", "top at 25%") 
    ,
    newKey("next", " ")
        .wait()
)

// The informed consent is presented to the participant
newTrial("Consent",
    newHtml("consent_form", "consent.html")
        .center()
        .cssContainer({"width":"720px"})
        .checkboxWarning("You must consent before continuing.")
        .print()
        .log()
    ,
    newButton("continue", "Click to continue")
        .center()
        .print()
        .wait(getHtml("consent_form").test.complete()
                  .failure(getHtml("consent_form").warn())
        )
    ,
    fullscreen()
)

// Instructions on how to set up the webcam and calibrate the eyetracker are shown.
PennController("WebcamSetUp",
    newText("WebcamSetUpText", 
            `<p>The next pages will help you set up the audio and webcam.
             The webcam will be set up in a simple calibration procedure.
             During this calibration, you will see a video of your webcam stream.
             Again, we will not save any recordings of this video stream. </p>
             Please make sure your face is fully visible, and that you sit
             centrally in front of your webcam by following the instructions
             in the picture below.</p>
            <p>In the calibration procedure, you will see eight buttons on 
            your screen. Please <b>click on all these buttons and 
            follow your cursor closely with your eyes</b>. Once 
            you've clicked on all buttons, a new button will appear in 
            the middle of the screen. Please click on this button and 
            <b>look at it for three seconds</b> so the algorithm can 
            check whether it's well calibrated.</p>
            <p>In case calibration fails, the last step will be repeated.
            <b>If calibration fails three times in a row</b>, 
            you won't be able to complete the experiment. If this 
            happens, you will be suggested to participate in another
            experiment. </p>
            <p>Press <b>SPACE</b> to continue to the next trial.</p>`)
        .css("font-family", "Arial, sans-serif")
    ,
    newImage("Instructions", "Instructions.png")
        .size("60vw")
    ,
    newCanvas("InstructionsCanvas", "60vw" , "20vh")
        .add(0,0, getText("WebcamSetUpText"))
        .print("center at 50%", "top at 20%") 
    ,
    getImage("Instructions")
        .print("center at 50%", "top at 65%")
    ,
    newKey("next", " ")
        .wait(newEyeTracker("tracker").test.ready())
    ,
    getCanvas("InstructionsCanvas")
        .remove()
    ,
    getImage("Instructions")
        .remove()
    ,
    newVar("Failed", "no")
        .global()
    ,
    fullscreen()
    ,
    //  Launch the calibration procedure
    getEyeTracker("tracker")
        .showFeedback() // Only during the initial calibration process
        .calibrate(40, 3) // Using the default error message
        .test.score(40)
            .failure(
                getVar("Failed")
                    .set("yes")
                        )
        .log()
)

// In case of FailedCalibration (No confirmation code)
newTrial("FailedCalibrationLink",
    getVar("Failed")
        .test.is("yes")
        .success(
            getVar("Subject")
                .log()
            ,
            newHtml("downloadspeed", "speedtest.html")
                .log()
            ,
            SendResults()
            ,
            newText("FailedCalibration", 
                    `<p>Unfortunately, the calibration failed. <br> It seems 
                    that the webcam is not able to pick up your eye 
                    movements. We kindly suggest to participate in a 
                    different experiment. </p> 
                    <p>Thank you for your interest in participating.</p>`)
                .css("font-family", "Arial, sans-serif")
                .print("Center at 50%", "Middle at 50%")
            , 
            newButton("waitforever").wait()
            )
    )

// In case of FailedCalibration
newTrial("FailedCalibrationLinkCode",
    getVar("Failed")
        .test.is("yes")
        .success(
            getVar("Subject")
                .log()
            ,
            newHtml("downloadspeed", "speedtest.html")
                .log()
            ,
            SendResults()
            ,
            newText("FailedCalibration", 
                    `<p>Unfortunately, the calibration failed. <br> It seems 
                    that the webcam is not able to pick up your eye 
                    movements. </p> 
                    <p> Your Prolific confirmation code is 
                    <b>C1464IHV</b>. </p> 
                    <p>Thank you for participating!</p>`)
                .css("font-family", "Arial, sans-serif")
                .print("Center at 50%", "Middle at 50%")
            , 
            newButton("waitforever").wait()
            )
    )
    
// Audio set up
PennController("AudioSetUp",
    newText("AudioInstructions", "Now that you have set up and calibrated the webcam, let’s set up the audio. In this experiment, you will hear a number of sentences. You can play one of the sentences that will be used in the experiment by clicking the play button below. Please use this audio recording to adjust your volume. Feel free to replay this sentence as often as you need. Once you’re ready, you can go to the next page.")
        .css("font-family", "Arial, sans-serif")
    ,
    newAudio("Volume_sentence", "audio-check-01.wav")
        .play()
    ,
    newCanvas( "myCanvas", "60vw" , "60vh")
        .settings.add(0,0, getText("AudioInstructions"))
        .settings.add("center at 50%", "top at 20%", getAudio("Volume_sentence"))
        .print("center at 50%", "top at 25%") 
    ,
    newButton("Take me to the next page")
        .center()
        .print("center at 50%", "top at 70%") 
        .wait()
)

// Task instructions 
newTrial("Instructions", 
    newHtml("downloadspeed", "speedtest.html")
        .log()
    ,
    newText("TaskInstructions", 
            `<p>Before each trial, you will see a circle in the middle 
            of your screen. <br> <b>Click on the circle and look at it 
            for three seconds.</b><br> 
            The webcam will check whether it 
            is still calibrated. If it is, the trial will automatically 
            start after three seconds. Otherwise, the calibration 
            procedure will be repeated. </p> 
            <p>You will hear a couple of short sentences while you 
            look at the screen.<br> <b>Listen to the sentence and click 
            one of the four images</b>, according to the instruction.<br>
            Please make sure you keep your head as still as possible 
            throughout the experiment.</p>
            <p>The experiment should take roughly 30 minutes to complete,
            and there will be a break in the middle. <br> It may take some 
            time to load images -- please give enough time for them to 
            load, and <b>do not refresh the page</b>.</p>
            <p>We’ll first start with some practice trials, and then 
            continue with the main experiment.</p>`)
        .css("font-family", "Arial, sans-serif")
    ,
    newCanvas("myCanvas", 800 , 300)
        .settings.add(0,0, getText("TaskInstructions"))
        .print("center at 50%", "top at 25%")   
    ,
    newButton("Take me to the practice trials")
        .center()
        .print("center at 50%", "top at 70%")
        .wait()
)
  
// Practice trials
Template(
    GetTable("Practice.csv")
        .setGroupColumn("group") // Latin Square design based on 'group' column
    , 
    row => // The practice trial info is retrieved from a csv file
    newTrial("PracticeSession",
        fullscreen()
        ,
        newHtml("downloadspeed", "speedtest.html")
            .log()
        ,
        // The callback commands lets us log the X and Y coordinates 
        // of the estimated gaze-locations at each recorded moment 
        // in time (Thanks to Jeremy Zehr for writing this function)
        newEyeTracker("tracker",1).callback( function (x,y) {
            if (this != getEyeTracker("tracker")._element.elements[0]) return;
            getEyeTracker("tracker")._element.counts._Xs.push(x);
            getEyeTracker("tracker")._element.counts._Ys.push(y); 
            })
        ,
        newFunction(()=>{
            getEyeTracker("tracker")._element.counts._Xs = [];
            getEyeTracker("tracker")._element.counts._Ys = [];
        }).call()  
        ,  
        // Show the mouse cursor (needed if calibration fails)
        newFunction( ()=>{
            $("body").css({
                width: '100vw',
                height: '100vh',
                cursor: 'default'
           });
        }).call()
        ,
        getEyeTracker("tracker")
            .calibrate(0) // Letting everyone pass
            .test.score(0)
            .log()
        ,
        // Hide the mouse cursor
        newFunction( ()=>{
            $("body").css({
                width: '100vw',
                height: '100vh',
                cursor: 'none'
           });
        }).call()
        ,
        defaultImage.size("20vh", "20vh") // Images are this size (note that they are a square)
        ,
        // We positioning of the four images is random
        // This function makes an array of the four picture files, 
        // and shuffles this array
        images = [row.image1,row.image2,row.image3,row.image4].sort(v=>Math.random()-Math.random()) 
        ,
        // Fixation cross
        newText("fixationText", "<p>+</p>") // Define the fixation cross
            .settings.css("font-family", "avenir")
            .settings.color("black")
        ,
        newCanvas("FixationCross", "15vh", "15vh") // This is the center fixation canvas, presented at the start of each trial. 
            .add("center at 50%" , "middle at 50%" , getText("fixationText").css("font-size", "5vh"))
            .print("center at 50%" , "middle at 50%")
        ,
        newTimer(500) // Fixation for 500ms
            .start()
            .wait()
        ,
        newTimer("callback", 1)
            .callback(getCanvas("FixationCross").remove())
            .start()
        ,
        // And print the canvas that contains the stimuli
        newCanvas("TopLeft", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[0])) // retrieve the first image from the shuffled array
            .print("center at 25%", "middle at 25%")
            .log() 
        ,
        newCanvas("BottomLeft", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[1])) // retrieve the second image from the shuffled array
            .print("center at 25%", "middle at 75%")
            .log() 
        ,
        newCanvas("TopRight", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[2])) // retrieve the third image from the shuffled array
            .print("center at 75%", "middle at 25%")
            .log() 
        ,
        newCanvas("BottomRight", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[3])) // retrieve the fourth image from the shuffled array
            .print("center at 75%", "middle at 75%")
            .log() 
        ,
        newTimer(2200).start().wait() // 2200 ms preview time
        ,
        // start the eyetracker
        getEyeTracker("tracker")
        // We track the Canvas: making them bigger allows us to capture look-estimates slightly off the images themselves
            .add(   // We track the Canvas elements   
                getCanvas("TopLeft"),
                getCanvas("BottomLeft"),
                getCanvas("TopRight"),
                getCanvas("BottomRight") 
            )
            .log()
            .start()
        ,
        // play the audio
        newAudio("audio", row.audio)
            .log()
            .play()
            .wait()
        ,
        // add 500 ms overspill time after the audio has finished playing
        newTimer(500).start().wait()
        ,     
        getEyeTracker("tracker").stop() // Stop the eyetracker to prevent collecting unnecessary data
        ,
        // check whether the audio has indeed stopped playing
        getAudio("audio").wait("first")
        ,
        // 200 ms overspill time 
        newTimer(200).start().wait()
        ,
        // Selection
        newText()
            .text(row.question_pcibex)
            .center()
            .css("font-family", "Arial, sans-serif")
            .print()
        ,
        // Making mouse cursor to reappear on the screen after the
        // offset of the auditory stimuli
        newFunction( ()=>(document.querySelector("body").style.cursor='unset') ).call()
        ,
        newSelector("selection")
            .enableClicks()
            .add(getImage(images[0]), 
                 getImage(images[1]),
                 getImage(images[2]),
                 getImage(images[3]))
            .log()
            .wait()
        )
    // save the required trial info in the results file 
    .log( "subject"             , getVar("Subject")         )
    .log( "image1"              , row.image1                )
    .log( "image2"              , row.image2                )            
    .log( "image3"              , row.image3                )   
    .log( "image4"              , row.image4                )
    .log( "image_topleft"       , images[0]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_bottomleft"    , images[1]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_topright"      , images[2]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_bottomright"   , images[3]                 ) // save which image is printed here (since the array was shuffled)
    .log( "type"                , row.type                  )   
    .log( "item"                , row.item                  )
    .log( "audio"               , row.audio                 )           
    .log( "sentence"            , row.sentence              )           
    .log( "ViewportWidth"       , window.innerWidth         ) // Screensize: width
    .log( "ViewportHeight"      , window.innerHeight        ) // Screensize: heigth     
)

// Page that tells the participants that the practice trials are over and the experiment will begin. 
newTrial("EndOfPractice", 
    //show cursor     
    newFunction( ()=>{
        $("body").css({
            width: '100vw',
            height: '100vh',
            cursor: 'default'
           });
        }).call()
    ,
    newText("EndOfPracticeText", 
            `<p> Those were the practice trials.</p>
            <p> We will move onto the main experiment.
            Make sure to click and <b>look at the circle in the middle
            of your screen between trials</b>. If the calibration is
            unsuccessful, you will be given 2 chances to recalibrate 
            your eye gaze with your webcam; if recalibration fails
            the experiment will terminate. </p>
            <p> Please click on the button below to start 
            the experiment.</p>`)
        .css("font-family", "Arial, sans-serif") 
    ,
    newCanvas("myCanvas", 800 , 300)
        .settings.add("center at 50%",0, getText("EndOfPracticeText"))
        .print("center at 50%", "top at 25%")   
    ,
    newButton("Start the experiment")
        .center()
        .print("center at 50%", "top at 60%")
        .wait()
)

// We use the counter to assign lists to participants. The counter is increased here (so if people cannot continue to the experiment due to calibration issues or because they quit, we will hopfully still get a similar number of participants in each list)
SetCounter("Counter", "inc", 1);

// And we start the trials in Block 1 - Note that this section is a copy from the practice trials (with the exeption of the csv file name)
Template(
    GetTable("Block1_target.csv")
        .setGroupColumn("group")
    , 
    row => // Again, the trial info is stored in a csv file
    newTrial("Block1_target",
        // relaunch fullscreen (which only has an effect if the participant closed the fullscreen for whatever reason)
        fullscreen()
        ,
        newHtml("downloadspeed", "speedtest.html")
            .log()
        ,
        // The callback commands lets us log the X and Y coordinates of the estimated gaze-locations at each recorded moment in time (Thanks to Jeremy Zehr for writing this function)
        newEyeTracker("tracker",1).callback( function (x,y) {
            if (this != getEyeTracker("tracker")._element.elements[0]) return;
            getEyeTracker("tracker")._element.counts._Xs.push(x);
            getEyeTracker("tracker")._element.counts._Ys.push(y); 
            })
        ,
        newFunction(()=>{
            getEyeTracker("tracker")._element.counts._Xs = [];
            getEyeTracker("tracker")._element.counts._Ys = [];
        }).call()  
        ,  
        // Show the mouse cursor (needed if calibration fails)
        newFunction( ()=>{
            $("body").css({
                width: '100vw',
                height: '100vh',
                cursor: 'default'
           });
        }).call()
        ,
        getEyeTracker("tracker")
            .calibrate(30, 3)
            .test.score(30)
                .failure(
                    getVar("Failed")
                        .set("yes")
                )
            .log()
        ,
        // Stop when calibration score is below threshold
        // This will block progressing to the next step
        getVar("Failed")
            .test.is("yes")
            .success(
                getVar("Subject")
                    .log()
                ,
                newHtml("downloadspeed", "speedtest.html")
                    .log()
                ,
                newTimer(5)
                    .start()
                    .wait()
                ,
                SendResults()
                ,
                newText("FailedCalibration", 
                        `<p>Unfortunately, the calibration failed. <br> It seems 
                        that the webcam is not able to pick up your eye 
                        movements. </p> 
                        <p> Your Prolific confirmation code is 
                        <b>C1464IHV</b>. Copy and paste this to your
                        Prolific page.</p> 
                        <p>Thank you for participating!</p>`)
                    .css("font-family", "Arial, sans-serif")
                    .print("Center at 50%", "Middle at 50%")
                , 
                newButton("waitforever").wait()
                )
        ,
        // Hide the mouse cursor
        newFunction( ()=>{
            $("body").css({
                width: '100vw',
                height: '100vh',
                cursor: 'none'
           });
        }).call()
        ,
        defaultImage.size("20vh", "20vh") // Images are this size (note that they are a square)
        ,
        images = [row.image1,row.image2,row.image3,row.image4].sort(v=>Math.random()-Math.random()) // We positioning of the four images is random. This function is needed for the randomization. It makes an array of the four picture files, and shuffles this array.
        ,
        // Fixation cross
        newText("fixationText", "<p>+</p>") // Define the fixation cross
            .settings.css("font-family", "avenir")
            .settings.color("black")
        ,
        newCanvas("FixationCross", "15vh", "15vh") // This is the center fixation canvas, presented at the start of each trial. 
            .add("center at 50%" , "middle at 50%" , getText("fixationText").css("font-size", "5vh"))
            .print("center at 50%" , "middle at 50%")
        ,
        newTimer(500) // Fixation for 500ms
            .start()
            .wait()
        ,
        newTimer("callback", 1)
            .callback( getCanvas("FixationCross").remove())
            .start()
        ,
        // And print the canvas that contains the stimuli
        newCanvas("TopLeft", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[0])) // retrieve the first image from the shuffled array
            .print("center at 25%", "middle at 25%")
            .log() 
        ,
        newCanvas("BottomLeft", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[1])) // retrieve the second image from the shuffled array
            .print("center at 25%", "middle at 75%")
            .log() 
        ,
        newCanvas("TopRight", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[2])) // retrieve the third image from the shuffled array
            .print("center at 75%", "middle at 25%")
            .log() 
        ,
        newCanvas("BottomRight", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[3])) // retrieve the fourth image from the shuffled array
            .print("center at 75%", "middle at 75%")
            .log() 
        ,
        newTimer(2200).start().wait() // 2200 ms preview time
        ,
        // start the eyetracker
        getEyeTracker("tracker")
        // We track the Canvas: making them bigger allows us to capture look-estimates slightly off the images themselves
            .add(   // We track the Canvas elements   
                getCanvas("TopLeft"),
                getCanvas("BottomLeft"),
                getCanvas("TopRight"),
                getCanvas("BottomRight") 
            )
            .log()
            .start()
        ,
        // play the audio
        newAudio("audio", row.audio)
            .log()
            .play()
            .wait()
        ,
        // add 500 ms overspill time after the audio has finished playing
        newTimer(500).start().wait()
        ,     
        getEyeTracker("tracker").stop() // Stop the eyetracker to prevent collecting unnecessary data
        ,
        // check whether the audio has indeed stopped playing
        getAudio("audio").wait("first")
        ,
        // 200 ms overspill time 
        newTimer(200).start().wait()
        ,
        // Selection
        newText()
            .text(row.question_pcibex)
            .center()
            .css("font-family", "Arial, sans-serif")
            .print()
        ,
        newFunction( ()=>(document.querySelector("body").style.cursor='unset') ).call()
        ,
        newSelector("selection")
            .enableClicks()
            .add(getImage(images[0]), 
                 getImage(images[1]),
                 getImage(images[2]),
                 getImage(images[3]))
            .log()
            .wait()
        )
    // save the required trial info in the results file 
    .log( "Subject"             , getVar("Subject")         )
    .log( "image1"              , row.image1                )
    .log( "image2"              , row.image2                )            
    .log( "image3"              , row.image3                )   
    .log( "image4"              , row.image4                )
    .log( "image_topleft"       , images[0]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_bottomleft"    , images[1]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_topright"      , images[2]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_bottomright"   , images[3]                 ) // save which image is printed here (since the array was shuffled)
    .log( "type"                , row.type                  )
    .log( "group"               , row.group                 )
    .log( "item"                , row.item                  )
    .log( "condition"           , row.condition             )
    .log( "audio"               , row.audio                 )           
    .log( "sentence"            , row.sentence              )
    .log( "ViewportWidth"       , window.innerWidth         ) // Screensize: width
    .log( "ViewportHeight"      , window.innerHeight        ) // Screensize: heigth     
)

Template(
    GetTable("Block1_filler.csv")
        .setGroupColumn("group")
    ,
    row => // Again, the trial info is stored in a csv file
    newTrial("Block1_filler",
        // relaunch fullscreen (which only has an effect if the participant closed the fullscreen for whatever reason)
        fullscreen()
        ,
        newHtml("downloadspeed", "speedtest.html")
            .log()
        ,
        // The callback commands lets us log the X and Y coordinates of the estimated gaze-locations at each recorded moment in time (Thanks to Jeremy Zehr for writing this function)
        newEyeTracker("tracker",1).callback( function (x,y) {
            if (this != getEyeTracker("tracker")._element.elements[0]) return;
            getEyeTracker("tracker")._element.counts._Xs.push(x);
            getEyeTracker("tracker")._element.counts._Ys.push(y); 
            })
        ,
        newFunction(()=>{
            getEyeTracker("tracker")._element.counts._Xs = [];
            getEyeTracker("tracker")._element.counts._Ys = [];
        }).call()  
        ,  
        // Show the mouse cursor (needed if calibration fails)
        newFunction( ()=>{
            $("body").css({
                width: '100vw',
                height: '100vh',
                cursor: 'default'
           });
        }).call()
        ,
        getEyeTracker("tracker")
            .calibrate(30, 3)
            .test.score(30)
                .failure(
                    getVar("Failed")
                        .set("yes")
                )
            .log()
        ,
        // Stop when calibration score is below threshold
        // This will block progressing to the next step
        getVar("Failed")
            .test.is("yes")
            .success(
                getVar("Subject")
                    .log()
                ,
                newHtml("downloadspeed", "speedtest.html")
                    .log()
                ,
                newTimer(5)
                    .start()
                    .wait()
                ,
                SendResults()
                ,
                newText("FailedCalibration", 
                        `<p>Unfortunately, the calibration failed. <br> It seems 
                        that the webcam is not able to pick up your eye 
                        movements. </p> 
                        <p> Your Prolific confirmation code is 
                        <b>C1464IHV</b>. Copy and paste this to your
                        Prolific page.</p> 
                        <p>Thank you for participating!</p>`)
                    .css("font-family", "Arial, sans-serif")
                    .print("Center at 50%", "Middle at 50%")
                , 
                newButton("waitforever").wait()
                )
        ,
        // Hide the mouse cursor
        newFunction( ()=>{
            $("body").css({
                width: '100vw',
                height: '100vh',
                cursor: 'none'
           });
        }).call()
        ,
        defaultImage.size("20vh", "20vh") // Images are this size (note that they are a square)
        ,
        images = [row.image1,row.image2,row.image3,row.image4].sort(v=>Math.random()-Math.random()) // We positioning of the four images is random. This function is needed for the randomization. It makes an array of the four picture files, and shuffles this array.
        ,
        // Fixation cross
        newText("fixationText", "<p>+</p>") // Define the fixation cross
            .settings.css("font-family", "avenir")
            .settings.color("black")
        ,
        newCanvas("FixationCross", "15vh", "15vh") // This is the center fixation canvas, presented at the start of each trial. 
            .add("center at 50%" , "middle at 50%" , getText("fixationText").css("font-size", "5vh"))
            .print("center at 50%" , "middle at 50%")
        ,
        newTimer(500) // Wait for 500 ms
            .start()
            .wait()
        ,
        newTimer("callback", 1)
            .callback( getCanvas("FixationCross").remove())
            .start()
        ,
        // And print the canvas that contains the stimuli
        newCanvas("TopLeft", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[0])) // retrieve the first image from the shuffled array
            .print("center at 25%", "middle at 25%")
            .log() 
        ,
        newCanvas("BottomLeft", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[1])) // retrieve the second image from the shuffled array
            .print("center at 25%", "middle at 75%")
            .log() 
        ,
        newCanvas("TopRight", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[2])) // retrieve the third image from the shuffled array
            .print("center at 75%", "middle at 25%")
            .log() 
        ,
        newCanvas("BottomRight", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[3])) // retrieve the fourth image from the shuffled array
            .print("center at 75%", "middle at 75%")
            .log() 
        ,
        newTimer(2200).start().wait() // 2200 ms preview time
        ,
        // start the eyetracker
        getEyeTracker("tracker")
        // We track the Canvas: making them bigger allows us to capture look-estimates slightly off the images themselves
            .add(   // We track the Canvas elements   
                getCanvas("TopLeft"),
                getCanvas("BottomLeft"),
                getCanvas("TopRight"),
                getCanvas("BottomRight") 
            )
            .log()
            .start()
        ,
        // play the audio
        newAudio("audio", row.audio)
            .log()
            .play()
            .wait()
        ,
        // add 500 ms overspill time after the audio has finished playing
        newTimer(500).start().wait()
        ,     
        getEyeTracker("tracker").stop() // Stop the eyetracker to prevent collecting unnecessary data
        ,
        // check whether the audio has indeed stopped playing
        getAudio("audio").wait("first")
        ,
        // 200 ms overspill time 
        newTimer(200).start().wait()
        ,
        // Selection
        newText()
            .text(row.question_pcibex)
            .center()
            .css("font-family", "Arial, sans-serif")
            .print()
        ,
        newFunction( ()=>(document.querySelector("body").style.cursor='unset') ).call()
        ,
        newSelector("selection")
            .enableClicks()
            .add(getImage(images[0]), 
                 getImage(images[1]),
                 getImage(images[2]),
                 getImage(images[3]))
            .log()
            .wait()
        )
    // save the required trial info in the results file 
    .log( "Subject"             , getVar("Subject")         )
    .log( "image1"              , row.image1                )
    .log( "image2"              , row.image2                )            
    .log( "image3"              , row.image3                )   
    .log( "image4"              , row.image4                )
    .log( "image_topleft"       , images[0]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_bottomleft"    , images[1]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_topright"      , images[2]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_bottomright"   , images[3]                 ) // save which image is printed here (since the array was shuffled)
    .log( "type"                , row.type                  )
    .log( "group"               , row.group                 )
    .log( "item"                , row.item                  )
    .log( "condition"           , row.condition             )
    .log( "audio"               , row.audio                 )           
    .log( "sentence"            , row.sentence              )
    .log( "ViewportWidth"       , window.innerWidth         ) // Screensize: width
    .log( "ViewportHeight"      , window.innerHeight        ) // Screensize: heigth     
)

// Break between the blocks
PennController("BlinkBreak",
   //show cursor     
   newFunction( ()=>{
    $("body").css({
        width: '100vw',
        height: '100vh',
        cursor: 'default'
           });
        }).call()
    ,     
    newText("BlinkBreakText", 
            `<p>This was the first block of the experiment. Feel free 
            to take a five minute break. Please make sure that this 
            break is not much longer than five minutes. <br><br> 
            Click on the button below to continue to the final block 
            of the experiment.<br><br> Make sure you are centrally 
            seated before your webcam and to keep your head still 
            throughout the remainder of this experiment.</p>`)
    ,           
    newCanvas( "myCanvas", "60vw" , "60vh")
        .settings.add(0,0, getText("BlinkBreakText"))
        .css("font-family", "Arial, sans-serif")
        .print("center at 50%", "middle at 50%")         
    ,      
    newButton("Take me to the next block (which will appear in fullscreen again)")
        .print("center at 50%", "top at 45%")
        .wait()
    ,
    fullscreen()
)

// Set-up the audio again
PennController("AudioSetUp2",
    newText("AudioInstructions", "In case you need to adjust the volume again for the second block, feel free to replay this sentence as often as you need.")
        .css("font-family", "Arial, sans-serif")    
    ,
    newAudio("Volume_sentence", "audio-check-03.wav")
        .play()
    ,
    newCanvas("myCanvas", 600 , 300)
        .settings.add(0,0, getText("AudioInstructions"))
        .settings.add("center at 50%", "top at 20%", getAudio("Volume_sentence"))
        .print("center at 50%", "top at 25%") 
    ,
    newButton("Continue to the next block")
        .print("center at 50%", "top at 60%") 
        .wait( newEyeTracker("tracker").test.ready() )
)

// And we preent the trials in Block 2 - Like Block 1, this section is a copy from the practice trials (with the exeption of the csv file name)
Template(
    GetTable("Block2_target.csv")
        .setGroupColumn("group")
    , 
    row =>
    newTrial("Block2_target",
        // relaunch fullscreen (which only has an effect if the participant closed the fullscreen for whatever reason)
        fullscreen()
        ,
         newHtml("downloadspeed", "speedtest.html")
            .log()
        ,
        // The callback commands lets us log the X and Y coordinates of the estimated gaze-locations at each recorded moment in time (Thanks to Jeremy Zehr for writing this function)
        newEyeTracker("tracker",1).callback( function (x,y) {
            if (this != getEyeTracker("tracker")._element.elements[0]) return;
            getEyeTracker("tracker")._element.counts._Xs.push(x);
            getEyeTracker("tracker")._element.counts._Ys.push(y); 
            })
        ,
        newFunction(()=>{
            getEyeTracker("tracker")._element.counts._Xs = [];
            getEyeTracker("tracker")._element.counts._Ys = [];
        }).call()  
        ,
        // Show the mouse cursor (needed if calibration fails)
        newFunction( ()=>{
            $("body").css({
                width: '100vw',
                height: '100vh',
                cursor: 'default'
           });
        }).call()
        ,
        getEyeTracker("tracker")
            .calibrate(30, 3)
            .test.score(30)
                .failure(
                    getVar("Failed")
                        .set("yes")
                )
            .log()
        ,
        // Stop when calibration score is below threshold
        // This will block progressing to the next step
        getVar("Failed")
            .test.is("yes")
            .success(
                getVar("Subject")
                    .log()
                ,
                newHtml("downloadspeed", "speedtest.html")
                    .log()
                ,
                newTimer(5)
                    .start()
                    .wait()
                ,
                SendResults()
                ,
                newText("FailedCalibration", 
                        `<p>Unfortunately, the calibration failed. <br> It seems 
                        that the webcam is not able to pick up your eye 
                        movements. </p> 
                        <p> Your Prolific confirmation code is 
                        <b>C1464IHV</b>. Copy and paste this to your
                        Prolific page.</p> 
                        <p>Thank you for participating!</p>`)
                    .css("font-family", "Arial, sans-serif")
                    .print("Center at 50%", "Middle at 50%")
                , 
                newButton("waitforever").wait()
                )
        ,
        // Hide the mouse cursor
        newFunction( ()=>{
            $("body").css({
                width: '100vw',
                height: '100vh',
                cursor: 'none'
           });
        }).call()
        ,
        defaultImage.size("20vh", "20vh") // Images are this size (note that they are a square)
        ,
        images = [row.image1,row.image2,row.image3,row.image4].sort(v=>Math.random()-Math.random()) // We positioning of the four images is random. This function is needed for the randomization. It makes an array of the four picture files, and shuffles this array.
        ,
        // Fixation cross
        newText("fixationText", "<p>+</p>") // Define the fixation cross
            .settings.css("font-family", "avenir")
            .settings.color("black")
        ,
        newCanvas("FixationCross", "15vh", "15vh") // This is the center fixation canvas, presented at the start of each trial. 
            .add("center at 50%" , "middle at 50%" , getText("fixationText").css("font-size", "5vh"))
            .print("center at 50%" , "middle at 50%")
        ,
        newTimer(500) // Fixation for 500ms
            .start()
            .wait()
        ,
        newTimer("callback", 1)
            .callback( getCanvas("FixationCross").remove())
            .start()
        ,
        // And print the canvas that contains the stimuli
        newCanvas("TopLeft", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[0])) // retrieve the first image from the shuffled array
            .print("center at 25%", "middle at 25%")
            .log() 
        ,
        newCanvas("BottomLeft", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[1])) // retrieve the second image from the shuffled array
            .print("center at 25%", "middle at 75%")
            .log() 
        ,
        newCanvas("TopRight", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[2])) // retrieve the third image from the shuffled array
            .print("center at 75%", "middle at 25%")
            .log() 
        ,
        newCanvas("BottomRight", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[3])) // retrieve the fourth image from the shuffled array
            .print("center at 75%", "middle at 75%")
            .log() 
        ,
        newTimer(2200).start().wait() // 2200 ms preview time
        ,
        // start the eyetracker
        getEyeTracker("tracker")
        // We track the Canvas: making them bigger allows us to capture look-estimates slightly off the images themselves
            .add(   // We track the Canvas elements   
                getCanvas("TopLeft"),
                getCanvas("BottomLeft"),
                getCanvas("TopRight"),
                getCanvas("BottomRight") 
            )
            .log()
            .start()
        ,
        // play the audio
        newAudio("audio", row.audio)
            .log()
            .play()
            .wait()
        ,
        // add 500 ms overspill time after the audio has finished playing
        newTimer(500).start().wait()
        ,     
        getEyeTracker("tracker").stop() // Stop the eyetracker to prevent collecting unnecessary data
        ,
        // check whether the audio has indeed stopped playing
        getAudio("audio").wait("first")
        ,
        // 200 ms overspill time 
        newTimer(200).start().wait()
        ,
        // Selection
        newText()
            .text(row.question_pcibex)
            .center()
            .css("font-family", "Arial, sans-serif")
            .print()
        ,
        newFunction( ()=>(document.querySelector("body").style.cursor='unset') ).call()
        ,
        newSelector("selection")
            .enableClicks()
            .add(getImage(images[0]), 
                 getImage(images[1]),
                 getImage(images[2]),
                 getImage(images[3]))
            .log()
            .wait()
        )
    // save the required trial info in the results file 
    .log( "subject"             , getVar("Subject")         )
    .log( "image1"              , row.image1                )
    .log( "image2"              , row.image2                )            
    .log( "image3"              , row.image3                )   
    .log( "image4"              , row.image4                )
    .log( "image_topleft"       , images[0]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_bottomleft"    , images[1]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_topright"      , images[2]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_bottomright"   , images[3]                 ) // save which image is printed here (since the array was shuffled)
    .log( "type"                , row.type                  ) 
    .log( "group"               , row.group                 )
    .log( "item"                , row.item                  )
    .log( "condition"           , row.condition             )
    .log( "audio"               , row.audio                 )           
    .log( "sentence"            , row.sentence              )
    .log( "ViewportWidth"       , window.innerWidth         ) // Screensize: width
    .log( "ViewportHeight"      , window.innerHeight        ) // Screensize: heigth     
)

Template(
    GetTable("Block2_filler.csv")
        .setGroupColumn("group")
    , 
    row =>
    newTrial("Block2_filler",
        // relaunch fullscreen (which only has an effect if the participant closed the fullscreen for whatever reason)
        fullscreen()
        ,
        newHtml("downloadspeed", "speedtest.html")
            .log()
        ,
        // The callback commands lets us log the X and Y coordinates of the estimated gaze-locations at each recorded moment in time (Thanks to Jeremy Zehr for writing this function)
        newEyeTracker("tracker",1).callback( function (x,y) {
            if (this != getEyeTracker("tracker")._element.elements[0]) return;
            getEyeTracker("tracker")._element.counts._Xs.push(x);
            getEyeTracker("tracker")._element.counts._Ys.push(y); 
            })
        ,
        newFunction(()=>{
            getEyeTracker("tracker")._element.counts._Xs = [];
            getEyeTracker("tracker")._element.counts._Ys = [];
        }).call()  
        ,
        // Show the mouse cursor (needed if calibration fails)
        newFunction( ()=>{
            $("body").css({
                width: '100vw',
                height: '100vh',
                cursor: 'default'
           });
        }).call()
        ,
        getEyeTracker("tracker")
            .calibrate(30, 3)
            .test.score(30)
                .failure(
                    getVar("Failed")
                        .set("yes")
                )
            .log()
        ,
        // Stop when calibration score is below threshold
        // This will block progressing to the next step
        getVar("Failed")
            .test.is("yes")
            .success(
                getVar("Subject")
                    .log()
                ,
                newHtml("downloadspeed", "speedtest.html")
                    .log()
                ,
                newTimer(5)
                    .start()
                    .wait()
                ,
                SendResults()
                ,
                newText("FailedCalibration", 
                        `<p>Unfortunately, the calibration failed. <br> It seems 
                        that the webcam is not able to pick up your eye 
                        movements. </p> 
                        <p> Your Prolific confirmation code is 
                        <b>C1464IHV</b>. Copy and paste this to your
                        Prolific page.</p> 
                        <p>Thank you for participating!</p>`)
                    .css("font-family", "Arial, sans-serif")
                    .print("Center at 50%", "Middle at 50%")
                , 
                newButton("waitforever").wait()
                )
        ,
        // Hide the mouse cursor
        newFunction( ()=>{
            $("body").css({
                width: '100vw',
                height: '100vh',
                cursor: 'none'
           });
        }).call()
        ,
        defaultImage.size("20vh", "20vh") // Images are this size (note that they are a square)
        ,
        images = [row.image1,row.image2,row.image3,row.image4].sort(v=>Math.random()-Math.random()) // We positioning of the four images is random. This function is needed for the randomization. It makes an array of the four picture files, and shuffles this array.
        ,
        // Fixation cross
        newText("fixationText", "<p>+</p>") // Define the fixation cross
            .settings.css("font-family", "avenir")
            .settings.color("black")
        ,
        newCanvas("FixationCross", "15vh", "15vh") // This is the center fixation canvas, presented at the start of each trial. 
            .add("center at 50%" , "middle at 50%" , getText("fixationText").css("font-size", "5vh"))
            .print("center at 50%" , "middle at 50%")
        ,
        newTimer(500) // Fixation for 500ms
            .start()
            .wait()
        ,
        newTimer("callback", 1)
            .callback( getCanvas("FixationCross").remove())
            .start()
        ,
        // And print the canvas that contains the stimuli
        newCanvas("TopLeft", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[0])) // retrieve the first image from the shuffled array
            .print("center at 25%", "middle at 25%")
            .log() 
        ,
        newCanvas("BottomLeft", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[1])) // retrieve the second image from the shuffled array
            .print("center at 25%", "middle at 75%")
            .log() 
        ,
        newCanvas("TopRight", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[2])) // retrieve the third image from the shuffled array
            .print("center at 75%", "middle at 25%")
            .log() 
        ,
        newCanvas("BottomRight", "50vw", "50vh")
            .add("center at 50%", "middle at 50%", newImage(images[3])) // retrieve the fourth image from the shuffled array
            .print("center at 75%", "middle at 75%")
            .log() 
        ,
        newTimer(2200).start().wait() // 2200 ms preview time
        ,
        // start the eyetracker
        getEyeTracker("tracker")
        // We track the Canvas: making them bigger allows us to capture look-estimates slightly off the images themselves
            .add(   // We track the Canvas elements   
                getCanvas("TopLeft"),
                getCanvas("BottomLeft"),
                getCanvas("TopRight"),
                getCanvas("BottomRight") 
            )
            .log()
            .start()
        ,
        // play the audio
        newAudio("audio", row.audio)
            .log()
            .play()
            .wait()
        ,
        // add 500 ms overspill time after the audio has finished playing
        newTimer(500).start().wait()
        ,     
        getEyeTracker("tracker").stop() // Stop the eyetracker to prevent collecting unnecessary data
        ,
        // check whether the audio has indeed stopped playing
        getAudio("audio").wait("first")
        ,
        // 200 ms overspill time 
        newTimer(200).start().wait()
        ,
        // Selection
        newText()
            .text(row.question_pcibex)
            .center()
            .css("font-family", "Arial, sans-serif")
            .print()
        ,
        newFunction( ()=>(document.querySelector("body").style.cursor='unset') ).call()
        ,
        newSelector("selection")
            .enableClicks()
            .add(getImage(images[0]), 
                 getImage(images[1]),
                 getImage(images[2]),
                 getImage(images[3]))
            .log()
            .wait()
        )
    // save the required trial info in the results file 
    .log( "subject"             , getVar("Subject")         )
    .log( "image1"              , row.image1                )
    .log( "image2"              , row.image2                )            
    .log( "image3"              , row.image3                )   
    .log( "image4"              , row.image4                )
    .log( "image_topleft"       , images[0]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_bottomleft"    , images[1]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_topright"      , images[2]                 ) // save which image is printed here (since the array was shuffled)
    .log( "image_bottomright"   , images[3]                 ) // save which image is printed here (since the array was shuffled)
    .log( "type"                , row.type                  ) 
    .log( "group"               , row.group                 )
    .log( "item"                , row.item                  )
    .log( "condition"           , row.condition             )
    .log( "audio"               , row.audio                 )           
    .log( "sentence"            , row.sentence              )
    .log( "ViewportWidth"       , window.innerWidth         ) // Screensize: width
    .log( "ViewportHeight"      , window.innerHeight        ) // Screensize: heigth     
)

// LanguageQuestionnaire
newTrial("LanguageQuestionnairePage",
    //show cursor     
    newFunction( ()=>{
        $("body").css({
            width: '100vw',
            height: '100vh',
            cursor: 'default'
           });
        }).call()
    ,
    newHtml("LanguageQuestionnaire", "LanguageQuestionnaire.html")
        .cssContainer({"width":"720px"})
        .checkboxWarning("You must consent before continuing.")
        .print()
        .log()
    ,
    newButton("continue", "Continue")
        .center()
        .print()
        .wait(getHtml("LanguageQuestionnaire").test.complete()
                  .failure(getHtml("LanguageQuestionnaire").warn())
        )
)

// WebcamQuestionnairePage
// newTrial("WebcamQuestionnairePage",
//     newHtml("WebcamQuestionnaire", "WebcamQuestionnaire.html")
//         .cssContainer({"width":"720px"})
//         .checkboxWarning("You must consent before continuing.")
//         .print()
//         .log()
//     ,
//     newButton("continue", "Continue")
//         .center()
//         .print()
//         .wait(getHtml("WebcamQuestionnaire").test.complete()
//                   .failure(getHtml("WebcamQuestionnaire").warn())
//         )
// ) 

// Send the results to the server
SendResults("Send");

// Closing page
newTrial("FinalPage",
    exitFullscreen()
    ,
    newText("Final","This is the end of the experiment. <br> Thank you for your participation!")
    ,
    newCanvas("myCanvas", "60vw" , "60vh")
        .settings.add(0,0, getText("Final"))
        .css("font-family", "Arial, sans-serif")
        .print("center at 50%", "middle at 50%") 
    ,     
    newButton("waitforever").wait()
)
