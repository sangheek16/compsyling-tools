var shuffleSequence = seq("intro", "quest", "instr", rshuffle(startsWith("x")), rshuffle(startsWith("y")), "code");

var practiceItemTypes = ["practice"];
var centerItems = true;
var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: true,
        instructions: " ",
        randomOrder: false,
        hasCorrect: false
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

/*
AcceptabilityJudgment flashes a sentence "s"
	s can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/

var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
["quest", "Form", {consentRequired: true, html: {include: "quest.html" }} ],
["instr", "Form", {consentRequired: true, html: {include: "instr.html" }} ],
["code", "Form", {consentRequired: true, html: {include: "code.html" }} ],


[["x1", 1], "AcceptabilityJudgment", {s: {html: '<audio src="bear1.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["x2", 2], "AcceptabilityJudgment", {s: {html: '<audio src="bear2.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["x3", 3], "AcceptabilityJudgment", {s: {html: '<audio src="bear3.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["x4", 4], "AcceptabilityJudgment", {s: {html: '<audio src="bear4.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["x5", 5], "AcceptabilityJudgment", {s: {html: '<audio src="bear5.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["x6", 6], "AcceptabilityJudgment", {s: {html: '<audio src="bear6.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["x7", 7], "AcceptabilityJudgment", {s: {html: '<audio src="bear7.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["x8", 8], "AcceptabilityJudgment", {s: {html: '<audio src="bear8.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["x9", 9], "AcceptabilityJudgment", {s: {html: '<audio src="bear9.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["y1", 11], "AcceptabilityJudgment", {s: {html: '<audio src="bear1.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["y2", 12], "AcceptabilityJudgment", {s: {html: '<audio src="bear2.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["y3", 13], "AcceptabilityJudgment", {s: {html: '<audio src="bear3.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["y4", 14], "AcceptabilityJudgment", {s: {html: '<audio src="bear4.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["y5", 15], "AcceptabilityJudgment", {s: {html: '<audio src="bear5.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["y6", 16], "AcceptabilityJudgment", {s: {html: '<audio src="bear6.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["y7", 17], "AcceptabilityJudgment", {s: {html: '<audio src="bear7.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["y8", 18], "AcceptabilityJudgment", {s: {html: '<audio src="bear8.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["y9", 19], "AcceptabilityJudgment", {s: {html: '<audio src="bear9.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

/*comma*/

];